create
    definer = root@localhost function getNthHighestSalary(N int) returns int
BEGIN
    SET N = N - 1;
    RETURN (
        SELECT
               IFNULL(Salary,null)
        FROM
             n_high
        ORDER BY
                 Salary
                 DESC
        LIMIT 1 OFFSET N
    );
END;

